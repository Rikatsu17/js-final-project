<h1>ARCADE GAMES</h1>
<B><P>Final Project WEB technologies</P></B>
<p>creators: Daniyal Adilbekov, Rassul Sakenov, Abyz Satbek, Aitkali Shilten, Aryn Yerassyl</p>
<p>Group: SE-2435</p>
<p>Teacher: Makhmetova Kuralay</p>

<b><h2>The Main Idea</h2></b>
<p>Creating website with the mini-games is really fun and interesting! also creating something like this for us is important because we're having an expirience, understanding basic materials and creating new skills</p>

<h2><b>What We Used</b></h2>

<p>HTML, CSS, JS, JQUERY, BOOTSTRAP and etc.</p>
